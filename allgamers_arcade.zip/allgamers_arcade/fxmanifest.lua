fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'allgamers_arcade'
author 'AllGamers'
description 'Retro handheld console with 7 playable mini-games, opened from an inventory item'
version '1.1.0'

ui_page 'web/index.html'

shared_script '@ox_lib/init.lua'
client_script 'client/main.lua'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

files {
    'config.lua',
    'bridge/framework.lua',
    'locales/*.json',
    'web/index.html',
    'web/style.css',
    'web/app.js'
}

dependencies {
    'ox_lib',
    'oxmysql'
}

escrow_ignore {
    'config.lua',
    'locales/*.json',
    'bridge/framework.lua',
    'server/main.lua'
}
