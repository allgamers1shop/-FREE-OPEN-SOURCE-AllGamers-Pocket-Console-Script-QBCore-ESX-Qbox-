local Config = require 'config'

---@class ArcadeFramework
---@field name string
local M = { name = 'standalone' }

local function detect()
    if Config.framework ~= 'auto' then return Config.framework end
    if GetResourceState('qbx_core') == 'started' then return 'qbx' end
    if GetResourceState('qb-core') == 'started' then return 'qb' end
    if GetResourceState('es_extended') == 'started' then return 'esx' end
    return 'standalone'
end

M.name = detect()
M.canPay = M.name ~= 'standalone'

local QB, ESX
if M.name == 'qb' then QB = exports['qb-core']:GetCoreObject() end
if M.name == 'esx' then ESX = exports['es_extended']:getSharedObject() end

---@param src number
---@return { cid: string, name: string }?
function M.getPlayer(src)
    if M.name == 'qbx' then
        local p = exports.qbx_core:GetPlayer(src)
        if not p then return end
        local ci = p.PlayerData.charinfo
        return { cid = p.PlayerData.citizenid, name = ('%s %s'):format(ci.firstname, ci.lastname) }
    elseif M.name == 'qb' then
        local p = QB.Functions.GetPlayer(src)
        if not p then return end
        local ci = p.PlayerData.charinfo
        return { cid = p.PlayerData.citizenid, name = ('%s %s'):format(ci.firstname, ci.lastname) }
    elseif M.name == 'esx' then
        local p = ESX.GetPlayerFromId(src)
        if not p then return end
        return { cid = p.identifier, name = (p.getName and p.getName()) or ('Player %d'):format(src) }
    else
        local lic = GetPlayerIdentifierByType(src, 'license') or ('src:' .. src)
        return { cid = lic, name = GetPlayerName(src) or ('Player %d'):format(src) }
    end
end

---@param src number
---@param mtype string
---@param amount number
---@param reason string
function M.addMoney(src, mtype, amount, reason)
    if amount <= 0 then return end
    if M.name == 'qbx' then
        exports.qbx_core:AddMoney(src, mtype, amount, reason)
    elseif M.name == 'qb' then
        local p = QB.Functions.GetPlayer(src)
        if p then p.Functions.AddMoney(mtype, amount, reason) end
    elseif M.name == 'esx' then
        local p = ESX.GetPlayerFromId(src)
        if p then
            if mtype == 'bank' then p.addAccountMoney('bank', amount) else p.addMoney(amount) end
        end
    end
end

---@param item string
---@param fn fun(src: number)
function M.registerUsable(item, fn)
    if M.name == 'qbx' then
        exports.qbx_core:CreateUseableItem(item, fn)
    elseif M.name == 'qb' then
        QB.Functions.CreateUseableItem(item, fn)
    elseif M.name == 'esx' then
        ESX.RegisterUsableItem(item, fn)
    end
end

return M
