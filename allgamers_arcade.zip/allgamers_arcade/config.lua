---@class ArcadePayout
---@field enabled boolean
---@field moneyType string
---@field perPoint number
---@field maxPerRun number
---@field cooldownMs number

---@class ArcadeSound
---@field enabled boolean
---@field volume number   0.0 - 1.0

---@class ArcadeAnim
---@field enabled boolean
---@field dict string
---@field clip string
---@field flag number
---@field prop string|false   attached hand prop, false to disable
---@field propBone number
---@field propPos vector3
---@field propRot vector3

---@class ArcadeConfig
---@field itemName string
---@field useKeybind boolean
---@field keybindDefault string
---@field command string|false
---@field framework string   'auto'|'qbx'|'qb'|'esx'|'standalone'
---@field inventory string    'auto'|'ox'|'qb'
---@field database string     'oxmysql'|'none'
---@field sound ArcadeSound
---@field animation ArcadeAnim
---@field games string[]
---@field payout ArcadePayout
---@field scoreClamp table<string, number>

return {
    -- Item that opens the console. Add it to your inventory (see README).
    itemName = 'retro_console',

    -- Optional keybind + command to open (independent of the item).
    useKeybind = false,
    keybindDefault = 'F3',
    command = 'arcade',

    -- 'auto' detects the running framework/inventory. Override if detection is wrong.
    framework = 'qb',     -- 'auto' | 'qbx' | 'qb' | 'esx' | 'standalone'
    inventory = 'qb',     -- 'auto' | 'ox' | 'qb'
    database = 'oxmysql',  -- 'oxmysql' (global leaderboard) | 'none'

    -- Self-contained chiptune sound (WebAudio, no external assets).
    sound = { enabled = true, volume = 0.35 },

    -- The player holds the handheld and taps at it while the console is open.
    -- Uses the vanilla texting animation + a small hand prop (both swappable).
    animation = {
        enabled = true,
        dict = 'cellphone@',
        clip = 'cellphone_text_read_base',
        flag = 49,                       -- 1 loop + 16 upper-body + 32 secondary
        prop = 'prop_npc_phone_02',      -- set to false for no prop
        propBone = 28422,                -- SKEL_R_Hand
        propPos = vec3(0.0, 0.0, 0.0),   -- tune in-game if the prop sits wrong
        propRot = vec3(0.0, 0.0, 0.0)
    },

    games = { 'badlands', 'turbo', 'cash', 'viper', 'leap', 'stacker', 'bricker' },

    -- Arcade score is reported by the client, so any payout is inherently client-trusted.
    -- Keep OFF unless you accept that; the server still clamps the score and rate-limits.
    payout = {
        enabled = false,
        moneyType = 'cash',
        perPoint = 0.0,
        maxPerRun = 0,
        cooldownMs = 60000
    },

    scoreClamp = {
        badlands = 100000, turbo = 100000, cash = 100000, viper = 10000,
        leap = 100000, stacker = 100000, bricker = 100000
    }
}
