(() => {
  const W = 160, H = 144;
  const P = ['#9bbc0f', '#8bac0f', '#306230', '#0f380f'];
  const canvas = document.getElementById('scr');
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;

  // English defaults / fallback. In-game these are overwritten by the strings
  // the client sends from locales/*.json, so translation lives entirely in locale files.
  const DEFAULT_L = {
    title: 'W - P O C K E T', records: 'RECORDS',
    hint_menu: 'A PLAY  B EXIT', hint_records: 'A VIEW  B BACK', hint_back: 'B BACK',
    game_over: 'GAME OVER', score: 'SCORE', best: 'BEST', saving: 'SAVING...',
    press_a: 'PRESS A', loading: 'LOADING...', no_scores: 'NO SCORES YET', lives: 'LIVES',
    sub_label: 'DOT MATRIX WITH STEREO SOUND', btn_select: 'SELECT', btn_start: 'START',
    controls_hint: '← ↑ ↓ → move  ·  Z = A  ·  X = B  ·  ESC = exit',
    g_badlands: 'BADLANDS REVENGE', g_turbo: 'TURBO LANE', g_cash: 'CASH GRAB', g_viper: 'VIPER',
    g_leap: 'SUPER LEAP', g_stacker: 'STACKER', g_bricker: 'BRICKER'
  };
  let L = Object.assign({}, DEFAULT_L);
  const t = k => (L[k] != null ? L[k] : k);
  const gameName = k => t('g_' + k);
  function applyI18n() {
    document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  }

  const RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'allgamers_arcade';
  async function post(name, data) {
    try {
      const r = await fetch(`https://${RES}/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data || {})
      });
      return await r.json();
    } catch (e) { return null; }
  }

  // ---- sound (self-contained chiptune, no assets) ----
  let actx = null, soundOn = true, vol = 0.35;
  const SFX = {
    move: [220, 'square', 0.05], select: [523, 'square', 0.10], start: [392, 'square', 0.16],
    fire: [880, 'square', 0.04], hit: [180, 'square', 0.08], coin: [740, 'square', 0.07],
    jump: [440, 'square', 0.14], die: [200, 'sawtooth', 0.4], line: [660, 'square', 0.2]
  };
  function sfx(name) {
    if (!soundOn) return;
    const d = SFX[name];
    if (!d) return;
    try {
      if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
      const t = actx.currentTime, o = actx.createOscillator(), g = actx.createGain();
      o.type = d[1];
      o.frequency.setValueAtTime(d[0], t);
      if (name === 'coin') o.frequency.exponentialRampToValueAtTime(d[0] * 1.5, t + 0.05);
      else if (name === 'jump') o.frequency.exponentialRampToValueAtTime(d[0] * 1.7, t + 0.11);
      else if (name === 'die') o.frequency.exponentialRampToValueAtTime(55, t + 0.34);
      else if (name === 'line') { o.frequency.setValueAtTime(d[0] * 1.25, t + 0.07); o.frequency.setValueAtTime(d[0] * 1.5, t + 0.14); }
      else if (name === 'start') o.frequency.setValueAtTime(d[0] * 1.5, t + 0.08);
      g.gain.setValueAtTime(Math.max(0.001, vol), t);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d[2]);
      o.connect(g); g.connect(actx.destination);
      o.start(t); o.stop(t + d[2] + 0.02);
    } catch (e) { }
  }

  // ---- input ----
  const down = new Set(), taps = new Set();
  function press(b) {
    if (actx && actx.state === 'suspended') actx.resume();
    if (!down.has(b)) taps.add(b);
    down.add(b);
  }
  function release(b) { down.delete(b); }
  const held = b => down.has(b);
  const tap = b => taps.has(b);

  const KEYMAP = {
    ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right',
    ArrowUp: 'up', KeyW: 'up', ArrowDown: 'down', KeyS: 'down',
    KeyZ: 'a', Enter: 'a', KeyX: 'b', Backspace: 'b', Escape: 'esc'
  };
  window.addEventListener('keydown', e => { const b = KEYMAP[e.code]; if (b) { e.preventDefault(); press(b); } });
  window.addEventListener('keyup', e => { const b = KEYMAP[e.code]; if (b) release(b); });
  document.querySelectorAll('[data-btn]').forEach(el => {
    const b = el.dataset.btn;
    el.addEventListener('pointerdown', e => { e.preventDefault(); press(b); });
    el.addEventListener('pointerup', () => release(b));
    el.addEventListener('pointerleave', () => release(b));
    el.addEventListener('pointercancel', () => release(b));
  });

  // ---- draw helpers ----
  function clear(i) { ctx.fillStyle = P[i]; ctx.fillRect(0, 0, W, H); }
  function rect(x, y, w, h, i) { ctx.fillStyle = P[i]; ctx.fillRect(Math.floor(x), Math.floor(y), Math.ceil(w), Math.ceil(h)); }
  function tri(x1, y1, x2, y2, x3, y3, i) {
    ctx.fillStyle = P[i]; ctx.beginPath();
    ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.lineTo(x3, y3); ctx.closePath(); ctx.fill();
  }
  function text(s, x, y, i, size) {
    ctx.fillStyle = P[i == null ? 3 : i];
    ctx.font = (size || 8) + 'px "Courier New", monospace';
    ctx.textBaseline = 'top';
    ctx.fillText(s, Math.round(x), Math.round(y));
  }
  function ctext(s, y, i, size) {
    ctx.font = (size || 8) + 'px "Courier New", monospace';
    const w = ctx.measureText(s).width;
    text(s, (W - w) / 2, y, i, size);
  }
  function hud(score) { rect(0, 0, W, 10, 3); text(t('score') + ' ' + score, 3, 1, 0); }
  function cell2(x, y, i) { rect(x, y, 7, 7, i); rect(x, y, 7, 1, i === 3 ? 2 : 0); }
  function car(cx, y, i) {
    rect(cx - 8, y, 16, 22, i); rect(cx - 6, y + 4, 12, 6, 0);
    rect(cx - 8, y - 2, 3, 5, 3); rect(cx + 5, y - 2, 3, 5, 3);
  }

  // ================= GAMES =================
  const badlands = {
    reset() { this.px = 80; this.py = 118; this.bul = []; this.en = []; this.t = 0; this.spawn = 0; this.fire = 0; this.score = 0; this.dead = false; },
    update(dt) {
      this.t += dt;
      const spd = 78;
      if (held('left')) this.px -= spd * dt;
      if (held('right')) this.px += spd * dt;
      if (held('up')) this.py -= spd * dt;
      if (held('down')) this.py += spd * dt;
      this.px = Math.max(7, Math.min(W - 7, this.px));
      this.py = Math.max(72, Math.min(H - 8, this.py));
      this.fire -= dt;
      if (held('a') && this.fire <= 0) { this.bul.push({ x: this.px, y: this.py - 7 }); this.fire = 0.2; sfx('fire'); }
      for (const b of this.bul) b.y -= 190 * dt;
      this.bul = this.bul.filter(b => b.y > -4);
      this.spawn -= dt;
      if (this.spawn <= 0) {
        this.en.push({ x: 9 + Math.random() * (W - 18), y: -6, vy: 24 + this.t * 1.6 + Math.random() * 14 });
        this.spawn = Math.max(0.32, 0.9 - this.t * 0.02);
      }
      for (const e of this.en) e.y += e.vy * dt;
      for (const e of this.en) {
        for (const b of this.bul) {
          if (Math.abs(b.x - e.x) < 6 && Math.abs(b.y - e.y) < 6) { e.hit = true; b.y = -99; this.score += 10; sfx('hit'); }
        }
        if (Math.abs(e.x - this.px) < 8 && Math.abs(e.y - this.py) < 7) { this.dead = true; sfx('die'); }
      }
      this.en = this.en.filter(e => !e.hit && e.y < H + 8);
    },
    draw() {
      clear(0);
      for (const b of this.bul) rect(b.x - 1, b.y - 3, 2, 5, 2);
      for (const e of this.en) { rect(e.x - 5, e.y - 4, 10, 8, 3); rect(e.x - 2, e.y, 4, 4, 0); }
      tri(this.px, this.py - 7, this.px - 6, this.py + 6, this.px + 6, this.py + 6, 3);
      rect(this.px - 2, this.py, 4, 5, 0);
      hud(this.score);
    }
  };

  const LANES = [44, 80, 116];
  const turbo = {
    reset() { this.lane = 1; this.obs = []; this.t = 0; this.spawn = 0; this.score = 0; this.road = 0; this.py = 116; this.dead = false; },
    update(dt) {
      this.t += dt;
      if (tap('left')) { this.lane = Math.max(0, this.lane - 1); sfx('move'); }
      if (tap('right')) { this.lane = Math.min(2, this.lane + 1); sfx('move'); }
      const speed = 70 + this.t * 7;
      this.road += speed * dt;
      this.spawn -= dt;
      if (this.spawn <= 0) { this.obs.push({ lane: Math.floor(Math.random() * 3), y: -26 }); this.spawn = Math.max(0.45, 1.1 - this.t * 0.02); }
      for (const o of this.obs) o.y += speed * dt;
      this.score += speed * dt * 0.12;
      for (const o of this.obs) {
        if (o.lane === this.lane && o.y + 22 > this.py && o.y < this.py + 22) { this.dead = true; sfx('die'); }
      }
      this.obs = this.obs.filter(o => o.y < H + 26);
    },
    draw() {
      clear(1);
      rect(24, 0, 3, H, 3); rect(133, 0, 3, H, 3);
      const off = this.road % 20;
      for (let y = -20 + off; y < H; y += 20) { rect(60, y, 3, 11, 3); rect(97, y, 3, 11, 3); }
      for (const o of this.obs) car(LANES[o.lane], o.y, 3);
      car(LANES[this.lane], this.py, 3);
      hud(Math.floor(this.score));
    }
  };

  const cash = {
    reset() { this.bx = 80; this.items = []; this.spawn = 0; this.t = 0; this.score = 0; this.dead = false; },
    update(dt) {
      this.t += dt;
      const spd = 120;
      if (held('left')) this.bx -= spd * dt;
      if (held('right')) this.bx += spd * dt;
      this.bx = Math.max(14, Math.min(W - 14, this.bx));
      this.spawn -= dt;
      if (this.spawn <= 0) {
        const bad = Math.random() < Math.min(0.36, 0.12 + this.t * 0.006);
        this.items.push({ x: 9 + Math.random() * (W - 18), y: -6, vy: 42 + this.t * 2 + Math.random() * 22, bad });
        this.spawn = Math.max(0.38, 0.85 - this.t * 0.02);
      }
      const by = 124;
      for (const it of this.items) {
        it.y += it.vy * dt;
        if (it.y > by - 5 && it.y < by + 8 && Math.abs(it.x - this.bx) < 14) {
          if (it.bad) { this.dead = true; sfx('die'); } else { this.score += 5; it.got = true; sfx('coin'); }
        }
      }
      this.items = this.items.filter(it => !it.got && it.y < H + 8);
    },
    draw() {
      clear(0);
      rect(this.bx - 13, 124, 26, 4, 3);
      rect(this.bx - 13, 124, 3, 9, 3); rect(this.bx + 10, 124, 3, 9, 3);
      for (const it of this.items) {
        if (it.bad) { rect(it.x - 4, it.y - 4, 8, 8, 3); rect(it.x - 1, it.y - 7, 2, 3, 3); }
        else { rect(it.x - 4, it.y - 4, 8, 8, 2); rect(it.x - 2, it.y - 2, 4, 4, 0); }
      }
      hud(this.score);
    }
  };

  const viper = {
    reset() {
      this.cols = 20; this.rows = 16; this.c = 8;
      this.snake = [{ x: 9, y: 8 }, { x: 8, y: 8 }, { x: 7, y: 8 }];
      this.dir = { x: 1, y: 0 }; this.nd = { x: 1, y: 0 };
      this.step = 0.16; this.acc = 0; this.score = 0; this.dead = false;
      this.food = this.place();
    },
    place() {
      let p;
      do { p = { x: (Math.random() * this.cols) | 0, y: (Math.random() * this.rows) | 0 }; }
      while (this.snake && this.snake.some(s => s.x === p.x && s.y === p.y));
      return p;
    },
    update(dt) {
      if (tap('up') && this.dir.y === 0) this.nd = { x: 0, y: -1 };
      if (tap('down') && this.dir.y === 0) this.nd = { x: 0, y: 1 };
      if (tap('left') && this.dir.x === 0) this.nd = { x: -1, y: 0 };
      if (tap('right') && this.dir.x === 0) this.nd = { x: 1, y: 0 };
      this.acc += dt;
      if (this.acc < this.step) return;
      this.acc = 0;
      this.dir = this.nd;
      const h = { x: this.snake[0].x + this.dir.x, y: this.snake[0].y + this.dir.y };
      if (h.x < 0 || h.y < 0 || h.x >= this.cols || h.y >= this.rows) { this.dead = true; sfx('die'); return; }
      for (const s of this.snake) if (s.x === h.x && s.y === h.y) { this.dead = true; sfx('die'); return; }
      this.snake.unshift(h);
      if (h.x === this.food.x && h.y === this.food.y) {
        this.score += 10; this.food = this.place(); this.step = Math.max(0.07, this.step - 0.004); sfx('coin');
      } else this.snake.pop();
    },
    draw() {
      clear(0);
      const gx = 0, gy = 12, c = this.c;
      rect(gx + this.food.x * c + 1, gy + this.food.y * c + 1, 6, 6, 3);
      for (let i = 0; i < this.snake.length; i++) {
        const s = this.snake[i];
        rect(gx + s.x * c, gy + s.y * c, 7, 7, i === 0 ? 3 : 2);
      }
      hud(this.score);
    }
  };

  // ---- SUPER LEAP (endless platformer, original) ----
  const leap = {
    reset() {
      this.camX = 0; this.px = 40; this.py = 105; this.vy = 0; this.onGround = true;
      this.gy = 112; this.segs = [{ x0: -20, x1: 210 }]; this.coins = []; this.foes = [];
      this.genUntil = 210; this.t = 0; this.score = 0; this.speed = 54; this.dead = false;
    },
    solidAt(wx) { for (const s of this.segs) if (wx >= s.x0 && wx < s.x1) return true; return false; },
    gen() {
      while (this.genUntil < this.camX + 250) {
        if (this.t > 3 && Math.random() < 0.26) this.genUntil += 22 + Math.random() * 18;
        const len = 42 + Math.random() * 72;
        const x0 = this.genUntil, x1 = x0 + len;
        this.segs.push({ x0, x1 });
        if (Math.random() < 0.6) this.coins.push({ x: x0 + 12 + Math.random() * (len - 24), y: this.gy - 14 - (Math.random() < 0.3 ? 20 : 0) });
        if (this.t > 4 && Math.random() < 0.4) this.foes.push({ x: x0 + len * 0.5, y: this.gy - 6, dir: -1 });
        this.genUntil = x1;
      }
      this.segs = this.segs.filter(s => s.x1 > this.camX - 40);
      this.coins = this.coins.filter(c => !c.got && c.x > this.camX - 20);
      this.foes = this.foes.filter(f => !f.dead && f.x > this.camX - 20);
    },
    update(dt) {
      this.t += dt; this.speed = 54 + this.t * 2.4;
      this.camX += this.speed * dt;
      this.score += this.speed * dt * 0.05;
      this.gen();
      if (held('left')) this.px = Math.max(16, this.px - 42 * dt);
      if (held('right')) this.px = Math.min(122, this.px + 42 * dt);
      const wx = this.camX + this.px;
      if ((tap('a') || tap('up')) && this.onGround) { this.vy = -158; this.onGround = false; sfx('jump'); }
      this.vy += 500 * dt; this.py += this.vy * dt;
      const over = this.solidAt(wx);
      if (over && this.py + 7 >= this.gy && this.vy >= 0) { this.py = this.gy - 7; this.vy = 0; this.onGround = true; }
      else { this.onGround = false; if (this.py > H + 12) { this.dead = true; sfx('die'); return; } }
      for (const c of this.coins) if (!c.got && Math.abs(c.x - wx) < 7 && Math.abs(c.y - this.py) < 9) { c.got = true; this.score += 5; sfx('coin'); }
      for (const f of this.foes) {
        f.x += f.dir * 24 * dt;
        if (Math.abs(f.x - wx) < 8) {
          if (this.vy > 20 && this.py < this.gy - 4) { f.dead = true; this.vy = -110; this.score += 10; sfx('hit'); }
          else if (Math.abs(f.y - this.py) < 9) { this.dead = true; sfx('die'); return; }
        }
      }
    },
    draw() {
      clear(0);
      for (const s of this.segs) { const sx = s.x0 - this.camX, w = s.x1 - s.x0; rect(sx, this.gy, w, H - this.gy, 3); rect(sx, this.gy, w, 2, 2); }
      for (const c of this.coins) if (!c.got) rect(c.x - this.camX - 3, c.y - 3, 6, 6, 2);
      for (const f of this.foes) if (!f.dead) { rect(f.x - this.camX - 5, f.y - 6, 10, 8, 3); rect(f.x - this.camX - 3, f.y - 4, 2, 2, 0); rect(f.x - this.camX + 1, f.y - 4, 2, 2, 0); }
      rect(this.px - 4, this.py - 8, 8, 15, 3); rect(this.px - 3, this.py - 6, 6, 4, 0);
      hud(Math.floor(this.score));
    }
  };

  // ---- STACKER (falling blocks, original) ----
  const PIECES = [
    [[0, 0], [1, 0], [2, 0], [3, 0]],
    [[0, 0], [1, 0], [0, 1], [1, 1]],
    [[0, 0], [1, 0], [2, 0], [1, 1]],
    [[1, 0], [2, 0], [0, 1], [1, 1]],
    [[0, 0], [1, 0], [1, 1], [2, 1]],
    [[0, 0], [0, 1], [1, 1], [2, 1]],
    [[2, 0], [0, 1], [1, 1], [2, 1]]
  ];
  const stacker = {
    reset() {
      this.cols = 10; this.rows = 16; this.grid = [];
      for (let r = 0; r < this.rows; r++) this.grid.push(new Array(this.cols).fill(0));
      this.acc = 0; this.step = 0.6; this.score = 0; this.lines = 0; this.dead = false;
      this.spawn();
    },
    spawn() {
      const i = (Math.random() * PIECES.length) | 0;
      this.piece = PIECES[i].map(c => ({ x: c[0] + 3, y: c[1] }));
      this.pcolor = 2 + (i % 2);
      if (this.collide(this.piece)) { this.dead = true; sfx('die'); }
    },
    collide(cells) {
      for (const c of cells) {
        if (c.x < 0 || c.x >= this.cols || c.y >= this.rows) return true;
        if (c.y >= 0 && this.grid[c.y][c.x]) return true;
      }
      return false;
    },
    rotate() {
      const p = this.piece[1];
      const nc = this.piece.map(c => ({ x: p.x - (c.y - p.y), y: p.y + (c.x - p.x) }));
      if (!this.collide(nc)) { this.piece = nc; sfx('move'); }
    },
    move(dx) { const nc = this.piece.map(c => ({ x: c.x + dx, y: c.y })); if (!this.collide(nc)) this.piece = nc; },
    lock() {
      for (const c of this.piece) if (c.y >= 0) this.grid[c.y][c.x] = this.pcolor;
      let cleared = 0;
      for (let r = this.rows - 1; r >= 0; r--) {
        if (this.grid[r].every(v => v)) { this.grid.splice(r, 1); this.grid.unshift(new Array(this.cols).fill(0)); cleared++; r++; }
      }
      if (cleared) { this.score += [0, 10, 25, 45, 70][cleared]; this.lines += cleared; this.step = Math.max(0.12, 0.6 - this.lines * 0.02); sfx('line'); }
      else sfx('hit');
      this.spawn();
    },
    dropStep() {
      const nc = this.piece.map(c => ({ x: c.x, y: c.y + 1 }));
      if (this.collide(nc)) this.lock(); else this.piece = nc;
    },
    update(dt) {
      if (tap('left')) this.move(-1);
      if (tap('right')) this.move(1);
      if (tap('a') || tap('up')) this.rotate();
      this.acc += dt;
      const s = held('down') ? 0.05 : this.step;
      if (this.acc >= s) { this.acc = 0; this.dropStep(); }
    },
    draw() {
      clear(0);
      const ox = 40, oy = 12, c = 8;
      rect(ox - 2, oy - 1, this.cols * c + 4, this.rows * c + 2, 3);
      rect(ox, oy, this.cols * c, this.rows * c, 1);
      for (let r = 0; r < this.rows; r++) for (let x = 0; x < this.cols; x++) if (this.grid[r][x]) cell2(ox + x * c, oy + r * c, this.grid[r][x]);
      for (const cc of this.piece) if (cc.y >= 0) cell2(ox + cc.x * c, oy + cc.y * c, this.pcolor);
      hud(this.score);
    }
  };

  // ---- BRICKER (brick breaker, original) ----
  const bricker = {
    reset() {
      this.px = 80; this.pw = 26; this.bx = 80; this.by = 118; this.vx = 72; this.vy = -72;
      this.score = 0; this.lives = 3; this.dead = false; this.launch = false; this.bricks = [];
      for (let r = 0; r < 4; r++) for (let c = 0; c < 8; c++) this.bricks.push({ x: 8 + c * 18, y: 20 + r * 8, w: 16, h: 6, a: true });
    },
    update(dt) {
      if (held('left')) this.px -= 130 * dt;
      if (held('right')) this.px += 130 * dt;
      this.px = Math.max(this.pw / 2, Math.min(W - this.pw / 2, this.px));
      if (!this.launch) { this.bx = this.px; this.by = 118; if (tap('a') || tap('up')) { this.launch = true; sfx('start'); } return; }
      this.bx += this.vx * dt; this.by += this.vy * dt;
      if (this.bx < 3) { this.bx = 3; this.vx = Math.abs(this.vx); }
      if (this.bx > W - 3) { this.bx = W - 3; this.vx = -Math.abs(this.vx); }
      if (this.by < 11) { this.by = 11; this.vy = Math.abs(this.vy); }
      if (this.by > 118 && this.by < 124 && Math.abs(this.bx - this.px) < this.pw / 2 + 2) {
        this.vy = -Math.abs(this.vy); this.vx += (this.bx - this.px) * 1.6; this.by = 118; sfx('hit');
      }
      if (this.by > H) {
        this.lives--; sfx('die');
        if (this.lives <= 0) { this.dead = true; return; }
        this.launch = false; this.vx = 72; this.vy = -72;
      }
      for (const b of this.bricks) {
        if (b.a && this.bx > b.x - 2 && this.bx < b.x + b.w + 2 && this.by > b.y - 2 && this.by < b.y + b.h + 2) {
          b.a = false; this.vy = -this.vy; this.score += 10; sfx('coin'); break;
        }
      }
      if (this.bricks.every(b => !b.a)) { for (const b of this.bricks) b.a = true; this.vx *= 1.1; this.vy *= 1.1; }
    },
    draw() {
      clear(0);
      for (const b of this.bricks) if (b.a) rect(b.x, b.y, b.w, b.h, 3);
      rect(this.px - this.pw / 2, 122, this.pw, 4, 3);
      rect(this.bx - 2, this.by - 2, 4, 4, 2);
      hud(this.score);
      text(t('lives') + ' ' + this.lives, W - 52, 1, 0);
    }
  };

  const Games = { badlands, turbo, cash, viper, leap, stacker, bricker };

  // ================= STATE / UI =================
  let mode = 'menu';
  let availGames = Object.keys(Games);
  let menuItems = availGames.concat(['records']);
  let cursor = 0, recCursor = 0;
  let cur = null, curKey = null;
  let overData = { score: 0, best: null, paid: 0, saving: false };
  let boardKey = null, boardRows = [], boardLoading = false;
  const VIS = 6;

  function winStart(c, len) {
    let s = c - (VIS >> 1);
    return Math.max(0, Math.min(s, Math.max(0, len - VIS)));
  }

  function closeConsole() {
    post('close');
    stop();
    document.getElementById('app').classList.add('hidden');
  }

  function onDead() {
    overData = { score: Math.floor(cur.score), best: null, paid: 0, saving: true };
    mode = 'over';
    post('saveScore', { game: curKey, score: overData.score }).then(res => {
      if (res && typeof res === 'object') { overData.best = res.best; overData.paid = res.paid || 0; }
      overData.saving = false;
    });
  }

  function openBoard(key) {
    boardKey = key; boardRows = []; boardLoading = true; mode = 'board';
    post('leaderboard', { game: key }).then(r => { boardRows = Array.isArray(r) ? r : []; boardLoading = false; });
  }

  function stepMenu() {
    if (tap('up')) { cursor = (cursor + menuItems.length - 1) % menuItems.length; sfx('move'); }
    if (tap('down')) { cursor = (cursor + 1) % menuItems.length; sfx('move'); }
    if (tap('esc') || tap('b')) return closeConsole();
    if (tap('a')) {
      const it = menuItems[cursor];
      sfx('start');
      if (it === 'records') { mode = 'records'; recCursor = 0; }
      else { curKey = it; cur = Games[it]; cur.reset(); mode = 'game'; }
    }
  }
  function stepOver() { if (tap('a') || tap('b') || tap('esc')) { sfx('select'); mode = 'menu'; } }
  function stepRecords() {
    if (tap('up')) { recCursor = (recCursor + availGames.length - 1) % availGames.length; sfx('move'); }
    if (tap('down')) { recCursor = (recCursor + 1) % availGames.length; sfx('move'); }
    if (tap('b') || tap('esc')) { mode = 'menu'; return; }
    if (tap('a')) { sfx('select'); openBoard(availGames[recCursor]); }
  }
  function stepBoard() { if (tap('b') || tap('esc')) mode = 'records'; }

  function drawListRow(label, i, st, sel) {
    const y = 26 + (i - st) * 15;
    if (sel) rect(6, y - 2, W - 12, 13, 2);
    text((sel ? '▸ ' : '  ') + label, 11, y, sel ? 0 : 3);
  }
  function drawMenu() {
    clear(0);
    rect(0, 0, W, 20, 3);
    ctext(t('title'), 5, 0, 11);
    const st = winStart(cursor, menuItems.length);
    for (let i = st; i < Math.min(menuItems.length, st + VIS); i++) {
      const it = menuItems[i];
      drawListRow(it === 'records' ? t('records') : gameName(it), i, st, i === cursor);
    }
    if (st > 0) text('▲', W - 12, 24, 2);
    if (st + VIS < menuItems.length) text('▼', W - 12, H - 20, 2);
    text(t('hint_menu'), 24, H - 11, 2);
  }
  function drawOver() {
    clear(0);
    ctext(t('game_over'), 26, 3, 14);
    ctext(t('score') + ' ' + overData.score, 58, 3, 9);
    if (overData.saving) ctext(t('saving'), 80, 2, 8);
    else {
      ctext(t('best') + ' ' + (overData.best == null ? '-' : overData.best), 80, 3, 8);
      if (overData.paid > 0) ctext('+ $' + overData.paid, 96, 2, 8);
    }
    ctext(t('press_a'), H - 16, 2, 8);
  }
  function drawRecords() {
    clear(0);
    rect(0, 0, W, 20, 3);
    ctext(t('records'), 5, 0, 11);
    const st = winStart(recCursor, availGames.length);
    for (let i = st; i < Math.min(availGames.length, st + VIS); i++) {
      drawListRow(gameName(availGames[i]), i, st, i === recCursor);
    }
    if (st > 0) text('▲', W - 12, 24, 2);
    if (st + VIS < availGames.length) text('▼', W - 12, H - 20, 2);
    text(t('hint_records'), 24, H - 11, 2);
  }
  function drawBoard() {
    clear(0);
    rect(0, 0, W, 18, 3);
    ctext(boardKey ? gameName(boardKey) : '', 5, 0, 10);
    if (boardLoading) ctext(t('loading'), 66, 3, 9);
    else if (!boardRows.length) ctext(t('no_scores'), 66, 3, 8);
    else {
      for (let i = 0; i < Math.min(6, boardRows.length); i++) {
        const r = boardRows[i], y = 26 + i * 15;
        let nm = (r.name || '???').toString();
        if (nm.length > 11) nm = nm.slice(0, 11);
        text((i + 1) + '.', 8, y, 3);
        text(nm, 26, y, 3);
        const sc = String(r.score);
        text(sc, W - 8 - ctx.measureText(sc).width, y, 3);
      }
    }
    text(t('hint_back'), W / 2 - 18, H - 11, 2);
  }

  function step(dt) {
    switch (mode) {
      case 'menu': stepMenu(); break;
      case 'game': cur.update(dt); if (cur.dead) onDead(); break;
      case 'over': stepOver(); break;
      case 'records': stepRecords(); break;
      case 'board': stepBoard(); break;
    }
    switch (mode) {
      case 'menu': drawMenu(); break;
      case 'game': cur.draw(); break;
      case 'over': drawOver(); break;
      case 'records': drawRecords(); break;
      case 'board': drawBoard(); break;
    }
  }

  let raf = null, last = 0, running = false;
  function loop(t) {
    if (!running) return;
    const dt = Math.min(0.05, (t - last) / 1000 || 0);
    last = t;
    step(dt);
    taps.clear();
    raf = requestAnimationFrame(loop);
  }
  function start() { if (running) return; running = true; last = performance.now(); raf = requestAnimationFrame(loop); }
  function stop() { running = false; if (raf) cancelAnimationFrame(raf); raf = null; }

  function powerBoot() {
    const p = document.querySelector('.power');
    if (!p) return;
    p.classList.remove('boot'); void p.offsetWidth; p.classList.add('boot');
  }

  window.addEventListener('message', e => {
    const d = e.data || {};
    if (d.action === 'open') {
      soundOn = d.sound !== false;
      vol = (typeof d.volume === 'number') ? d.volume : 0.35;
      if (d.strings && typeof d.strings === 'object') Object.assign(L, d.strings);
      applyI18n();
      const list = (Array.isArray(d.games) && d.games.length ? d.games : Object.keys(Games)).filter(g => Games[g]);
      availGames = list.length ? list : Object.keys(Games);
      menuItems = availGames.concat(['records']);
      cursor = 0; mode = 'menu';
      document.getElementById('app').classList.remove('hidden');
      powerBoot();
      start();
    } else if (d.action === 'close') {
      stop();
      document.getElementById('app').classList.add('hidden');
    }
  });

  if (typeof GetParentResourceName !== 'function') {
    document.getElementById('app').classList.remove('hidden');
    mode = 'menu'; powerBoot(); start();
  }
})();
