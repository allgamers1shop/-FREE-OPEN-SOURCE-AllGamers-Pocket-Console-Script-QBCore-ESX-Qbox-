local Config = require 'config'
local Framework = require 'bridge.framework'

lib.locale()

local RESOURCE = GetCurrentResourceName()
local TABLE = 'allgamers_arcade_scores'
local useDb = Config.database == 'oxmysql'
local gameSet = {}
local payoutCooldown = {}
local memoryScores = {}

for i = 1, #Config.games do
    gameSet[Config.games[i]] = true
end

function IsValidGame(game)
    return type(game) == 'string' and gameSet[game] == true
end

function ClampScore(game, score)
    local n = math.floor(tonumber(score) or 0)
    if n < 0 then n = 0 end
    local maxScore = Config.scoreClamp and Config.scoreClamp[game]
    if maxScore and n > maxScore then
        n = maxScore
    end
    return n
end

function EnsureDatabase()
    if not useDb then return end
    MySQL.query.await(([[
        CREATE TABLE IF NOT EXISTS `%s` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `citizenid` VARCHAR(64) NOT NULL,
            `name` VARCHAR(64) NOT NULL,
            `game` VARCHAR(32) NOT NULL,
            `score` INT NOT NULL DEFAULT 0,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_player_game` (`citizenid`, `game`),
            KEY `idx_game_score` (`game`, `score`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]]):format(TABLE))
end

function GetPersonalBest(citizenid, game)
    if useDb then
        local row = MySQL.single.await(
            ('SELECT `score` FROM `%s` WHERE `citizenid` = ? AND `game` = ? LIMIT 1'):format(TABLE),
            { citizenid, game }
        )
        return row and tonumber(row.score) or nil
    end

    local playerScores = memoryScores[citizenid]
    if not playerScores then return nil end
    return playerScores[game]
end

function SavePersonalBest(citizenid, name, game, score)
    local best = GetPersonalBest(citizenid, game)
    if best and score <= best then
        return best
    end

    if useDb then
        MySQL.insert.await(([[
            INSERT INTO `%s` (`citizenid`, `name`, `game`, `score`)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                `score` = IF(VALUES(`score`) > `score`, VALUES(`score`), `score`),
                `name` = VALUES(`name`)
        ]]):format(TABLE), { citizenid, name, game, score })
    else
        memoryScores[citizenid] = memoryScores[citizenid] or {}
        memoryScores[citizenid][game] = score
    end

    return score
end

function GetLeaderboard(game)
    if useDb then
        local rows = MySQL.query.await(
            ('SELECT `name`, `score` FROM `%s` WHERE `game` = ? ORDER BY `score` DESC LIMIT 6'):format(TABLE),
            { game }
        ) or {}

        local out = {}
        for i = 1, #rows do
            out[i] = {
                name = rows[i].name,
                score = tonumber(rows[i].score) or 0
            }
        end
        return out
    end

    local list = {}
    for citizenid, games in pairs(memoryScores) do
        local score = games[game]
        if score then
            list[#list + 1] = {
                name = games.__name or citizenid,
                score = score
            }
        end
    end

    table.sort(list, function(a, b)
        return a.score > b.score
    end)

    local out = {}
    for i = 1, math.min(6, #list) do
        out[i] = list[i]
    end
    return out
end

function TryPayout(src, score)
    local payout = Config.payout
    if not payout or not payout.enabled or not Framework.canPay then
        return 0
    end

    local perPoint = tonumber(payout.perPoint) or 0
    if perPoint <= 0 then return 0 end

    local now = GetGameTimer()
    local last = payoutCooldown[src] or 0
    local cooldown = tonumber(payout.cooldownMs) or 0
    if cooldown > 0 and (now - last) < cooldown then
        return 0
    end

    local amount = math.floor(score * perPoint)
    local maxPerRun = tonumber(payout.maxPerRun) or 0
    if maxPerRun > 0 and amount > maxPerRun then
        amount = maxPerRun
    end
    if amount <= 0 then return 0 end

    Framework.addMoney(src, payout.moneyType or 'cash', amount, 'allgamers_arcade payout')
    payoutCooldown[src] = now
    return amount
end

function OpenFor(src)
    TriggerClientEvent('allgamers_arcade:open', src)
end

lib.callback.register('allgamers_arcade:saveScore', function(source, game, score)
    if not IsValidGame(game) then
        return { best = nil, paid = 0 }
    end

    local player = Framework.getPlayer(source)
    if not player then
        return { best = nil, paid = 0 }
    end

    local clamped = ClampScore(game, score)
    if not useDb then
        memoryScores[player.cid] = memoryScores[player.cid] or {}
        memoryScores[player.cid].__name = player.name
    end

    local best = SavePersonalBest(player.cid, player.name, game, clamped)
    local paid = TryPayout(source, clamped)
    return { best = best, paid = paid }
end)

lib.callback.register('allgamers_arcade:leaderboard', function(_, game)
    if not IsValidGame(game) then
        return {}
    end
    return GetLeaderboard(game)
end)

-- ox_inventory item export: server = { export = 'allgamers_arcade.useConsole' }
exports('useConsole', function(event, item, inventory)
    if event ~= 'usingItem' then return end
    local src = type(inventory) == 'table' and inventory.id or inventory
    if type(src) == 'number' then
        OpenFor(src)
    end
end)

exports('open', function(src)
    if type(src) == 'number' then
        OpenFor(src)
    end
end)

AddEventHandler('playerDropped', function()
    payoutCooldown[source] = nil
end)

CreateThread(function()
    local deadline = GetGameTimer() + 30000
    while GetResourceState('qb-core') ~= 'started' and GetGameTimer() < deadline do
        Wait(200)
    end

    Framework.registerUsable(Config.itemName, function(src)
        OpenFor(src)
    end)

    if useDb then
        local ready = false
        MySQL.ready(function()
            local ok, err = pcall(EnsureDatabase)
            if not ok then
                print(('[%s] database init failed: %s'):format(RESOURCE, err))
                useDb = false
            end
            ready = true
            print(('[%s] server ready (framework=%s, database=%s, item=%s)'):format(
                RESOURCE, Framework.name, useDb and 'oxmysql' or 'memory', Config.itemName
            ))
        end)
        local waitUntil = GetGameTimer() + 15000
        while not ready and GetGameTimer() < waitUntil do
            Wait(100)
        end
        if not ready then
            useDb = false
            print(('[%s] server ready (framework=%s, database=memory fallback, item=%s)'):format(
                RESOURCE, Framework.name, Config.itemName
            ))
        end
    else
        print(('[%s] server ready (framework=%s, database=memory, item=%s)'):format(
            RESOURCE, Framework.name, Config.itemName
        ))
    end
end)
