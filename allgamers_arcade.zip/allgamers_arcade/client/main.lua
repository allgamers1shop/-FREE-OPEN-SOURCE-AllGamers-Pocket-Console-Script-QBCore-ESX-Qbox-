local Config = require 'config'

lib.locale()

local open = false
local animProp

local function startAnim()
    local a = Config.animation
    if not a or not a.enabled then return end
    local ped = cache.ped
    if lib.requestAnimDict(a.dict, 2000) then
        TaskPlayAnim(ped, a.dict, a.clip, 3.0, 3.0, -1, a.flag, 0.0, false, false, false)
    end
    if a.prop and lib.requestModel(a.prop, 2000) then
        local coords = GetEntityCoords(ped)
        animProp = CreateObject(joaat(a.prop), coords.x, coords.y, coords.z, true, true, false)
        AttachEntityToEntity(animProp, ped, GetPedBoneIndex(ped, a.propBone),
            a.propPos.x, a.propPos.y, a.propPos.z, a.propRot.x, a.propRot.y, a.propRot.z,
            true, true, false, true, 1, true)
        SetModelAsNoLongerNeeded(joaat(a.prop))
    end
end

local function stopAnim()
    local a = Config.animation
    if a and a.enabled then
        ClearPedTasks(cache.ped)
    end
    if animProp then
        DeleteObject(animProp)
        animProp = nil
    end
end

-- Every user-facing NUI string. Pulled from locales/*.json at open time and sent to
-- the interface, so all translation lives in the locale files (nothing hardcoded in JS).
local UI_KEYS <const> = {
    'title', 'records', 'hint_menu', 'hint_records', 'hint_back',
    'game_over', 'score', 'best', 'saving', 'press_a', 'loading', 'no_scores', 'lives',
    'sub_label', 'btn_select', 'btn_start', 'controls_hint',
    'g_badlands', 'g_turbo', 'g_cash', 'g_viper', 'g_leap', 'g_stacker', 'g_bricker'
}

---@return table<string, string>
local function buildStrings()
    local s = {}
    for i = 1, #UI_KEYS do
        local k = UI_KEYS[i]
        s[k] = locale(k)
    end
    return s
end

local function openConsole()
    if open then return end
    open = true
    SetNuiFocus(true, true)
    startAnim()
    SendNUIMessage({
        action = 'open',
        games = Config.games,
        sound = Config.sound.enabled,
        volume = Config.sound.volume,
        strings = buildStrings()
    })
end

local function closeConsole()
    if not open then return end
    open = false
    SetNuiFocus(false, false)
    stopAnim()
    SendNUIMessage({ action = 'close' })
end

exports('open', openConsole)
RegisterNetEvent('allgamers_arcade:open', openConsole)

RegisterNUICallback('close', function(_, cb)
    closeConsole()
    cb(1)
end)

RegisterNUICallback('saveScore', function(data, cb)
    local res = lib.callback.await('allgamers_arcade:saveScore', false, data.game, data.score)
    if res and type(res) == 'table' and res.paid and res.paid > 0 then
        lib.notify({ title = 'Arcade', description = locale('payout', res.paid), type = 'success' })
    end
    cb(res or {})
end)

RegisterNUICallback('leaderboard', function(data, cb)
    local rows = lib.callback.await('allgamers_arcade:leaderboard', false, data.game)
    cb(rows or {})
end)

if Config.command then
    RegisterCommand(Config.command, openConsole, false)
end

if Config.useKeybind then
    RegisterCommand('allgamers_arcade_open', openConsole, false)
    RegisterKeyMapping('allgamers_arcade_open', 'Open Arcade Console', 'keyboard', Config.keybindDefault)
end

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() and open then
        SetNuiFocus(false, false)
        stopAnim()
    end
end)
